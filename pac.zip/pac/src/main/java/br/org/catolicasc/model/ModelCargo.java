package br.org.catolicasc.model;

public class ModelCargo {
	
	private int id_cargo;
	private String ds_cargo;
	
	
	public int getId_cargo() {
		return id_cargo;
	}
	public void setId_cargo(int id_cargo) {
		this.id_cargo = id_cargo;
	}
	public String getDs_cargo() {
		return ds_cargo;
	}
	public void setDs_cargo(String ds_cargo) {
		this.ds_cargo = ds_cargo;
	}
	
}
