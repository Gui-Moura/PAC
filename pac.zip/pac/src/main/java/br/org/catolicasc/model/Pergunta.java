package br.org.catolicasc.model;

public class Pergunta {
	
	private int id_pergunta;
	

	public int getId_pergunta() {
		return id_pergunta;
	}

	public void setId_pergunta(int id_pergunta) {
		this.id_pergunta = id_pergunta;
	}

}
