package br.org.catolicasc.model;

public class Estado {
	
	private int id_estado;
	private String descEstado;
	
	
	public int getId_estado() {
		return id_estado;
	}
	public void setId_estado(int id_estado) {
		this.id_estado = id_estado;
	}
	public String getDescEstado() {
		return descEstado;
	}
	public void setDescEstado(String descEstado) {
		this.descEstado = descEstado;
	}
	
	public void exibirDados() {
		
	}

}
