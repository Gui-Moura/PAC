package br.org.catolicasc.model;

public class Imagem {
	
	private int id_imagem;
	private String referencia;
	
	
	public int getId_imagem() {
		return id_imagem;
	}
	public void setId_imagem(int id_imagem) {
		this.id_imagem = id_imagem;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

}
