package br.org.catolicasc.model;

public class Nivel {
	
	private int id_nivel;
	private String ds_nivel;
	
	
	public int getId_nivel() {
		return id_nivel;
	}
	public void setId_nivel(int id_nivel) {
		this.id_nivel = id_nivel;
	}
	public String getDs_nivel() {
		return ds_nivel;
	}
	public void setDs_nivel(String ds_nivel) {
		this.ds_nivel = ds_nivel;
	}

}
