package br.org.catolicasc.model;

public class Pontuacao {
	
	private int id_pontuacao;
	private int qt_pontos;
	
	
	public int getId_pontuacao() {
		return id_pontuacao;
	}
	public void setId_pontuacao(int id_pontuacao) {
		this.id_pontuacao = id_pontuacao;
	}
	public int getQt_pontos() {
		return qt_pontos;
	}
	public void setQt_pontos(int qt_pontos) {
		this.qt_pontos = qt_pontos;
	}
}
