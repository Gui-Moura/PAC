package br.org.catolicasc.model;

public class RelatorioDeDesempenho {
	
	private int id_rel_des;
	

	public int getId_rel_des() {
		return id_rel_des;
	}

	public void setId_rel_des(int id_rel_des) {
		this.id_rel_des = id_rel_des;
	}

}
